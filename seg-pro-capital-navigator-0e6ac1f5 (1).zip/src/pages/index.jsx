import React, { useState } from "react";
import { CalculatorSubmission } from "@/api/entities";
import InputPanel from "../components/calculator/InputPanel";
import ResultsPanel from "../components/calculator/ResultsPanel";
import { calculateDepreciation } from "../components/calculator/calculationEngine";

export default function Index() {
  const [inputs, setInputs] = useState({
    property_type: "residential_rental",
    placed_in_service_date: "2025-01-19",
    purchase_price: 1000000,
    cost_of_improvements: 0,
    estimated_land_percent: 20,
    federal_tax_rate: 37,
    current_tax_year: 2025,
    bonus_depreciation_percent: 100,
    bonus_override_100: true,
    land_value_override: null
  });

  const [results, setResults] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [activeTab, setActiveTab] = useState("reallocation");

  const handleInputChange = (field, value) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleCalculate = async () => {
    setIsCalculating(true);
    try {
      const calculatedResults = calculateDepreciation(inputs);
      setResults(calculatedResults);
      await CalculatorSubmission.create({ ...inputs, results: calculatedResults });
    } catch (error) {
      console.error("Calculation error:", error);
    } finally {
      setIsCalculating(false);
    }
  };

  // Auto-calculate on initial load to show something, matching the reference
  React.useEffect(() => {
    handleCalculate();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6 lg:p-8 font-sans">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <InputPanel
              inputs={inputs}
              onInputChange={handleInputChange}
              onCalculate={handleCalculate}
              isCalculating={isCalculating}
            />
          </div>
          <div className="lg:col-span-3">
            <ResultsPanel
              results={results}
              inputs={inputs}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              isCalculating={isCalculating}
            />
          </div>
        </div>
    </div>
  );
}