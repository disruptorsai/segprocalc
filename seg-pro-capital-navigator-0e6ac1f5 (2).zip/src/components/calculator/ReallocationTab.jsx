
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import CashFlowAnimation from "./CashFlowAnimation"; // Added import

const COLORS = {
  personalProperty: '#0A4EAF', // Primary Blue
  siteImprovements: '#60A5FA', // Medium Blue  
  realProperty: '#BFDBFE'     // Light Blue
};

const CATEGORY_LABELS = {
  personalProperty: 'Personal Property',
  siteImprovements: 'Site Improvements', 
  realProperty: 'Real Property'
};

export default function ReallocationTab({ results, inputs, isCalculating }) {
  const [viewMode, setViewMode] = useState('estimated');

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  if (isCalculating) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#0A4EAF] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#333333]">Calculating...</h3>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-[#777777]">Enter your details to see the asset reallocation breakdown.</p>
      </div>
    );
  }

  const currentAllocation = results.allocations[viewMode];
  
  const pieData = [
    {
      name: CATEGORY_LABELS.personalProperty,
      value: currentAllocation.percentages.personalProperty,
      amount: currentAllocation.amounts.personalProperty,
      color: COLORS.personalProperty,
      years: '5-yr'
    },
    {
      name: CATEGORY_LABELS.siteImprovements,
      value: currentAllocation.percentages.siteImprovements,
      amount: currentAllocation.amounts.siteImprovements,
      color: COLORS.siteImprovements,
      years: '15-yr'
    },
    {
      name: CATEGORY_LABELS.realProperty,
      value: currentAllocation.percentages.realProperty,
      amount: currentAllocation.amounts.realProperty,
      color: COLORS.realProperty,
      years: inputs.property_type === 'residential_rental' ? '27.5-yr' : '39-yr'
    }
  ];

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
    if (percent < 0.05) return null; // Don't show labels for very small slices
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor="middle" 
        dominantBaseline="central" 
        className="font-bold text-sm pointer-events-none"
        style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-bold text-[#333333] mb-2">
          Breakout of property into recovery periods
        </h2>
        <div className="flex justify-center items-center gap-x-6 mb-4">
          {pieData.map((entry, index) => (
            <div key={`legend-${index}`} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-sm text-[#777777]">{entry.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-grow relative">
        <ResponsiveContainer width="100%" height={350}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomizedLabel}
              innerRadius={80}
              outerRadius={140}
              paddingAngle={2}
              dataKey="value"
              startAngle={90}
              endAngle={450}
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} stroke="#ffffff" strokeWidth={2}/>
              ))}
            </Pie>
            <Tooltip
              formatter={(value, name, props) => [
                `${formatCurrency(props.payload.amount)} (${value.toFixed(0)}%)`,
                `${name} (${props.payload.years})`
              ]}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="flex justify-center">
        <div className="flex items-center p-1 bg-slate-200 rounded-lg">
          <Button
            variant={viewMode === 'estimated' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('estimated')}
            className={`rounded-md transition-all duration-200 ${
              viewMode === 'estimated' 
                ? 'bg-white text-[#333333] shadow-md' 
                : 'text-[#777777] hover:text-[#333333]'
            }`}
          >
            Baseline
          </Button>
          <Button
            variant={viewMode === 'optimistic' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('optimistic')}
            className={`rounded-md transition-all duration-200 ${
              viewMode === 'optimistic' 
                ? 'bg-white text-[#333333] shadow-md' 
                : 'text-[#777777] hover:text-[#333333]'
            }`}
          >
            Optimal
          </Button>
        </div>
      </div>
      
      {/* Inline Cash Flow Animation */}
      <div className="pt-6">
        <CashFlowAnimation 
          taxSavings={results?.fiveYearComparison?.taxSavings?.[viewMode] || 0} 
        />
      </div>

      {/* Before vs After Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Before */}
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 border-slate-200">
          <CardHeader>
            <CardTitle className="text-[#333333]">Before Cost Segregation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="w-24 h-24 bg-slate-300 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-slate-700 font-bold text-lg">100%</span>
              </div>
              <p className="text-[#777777] text-sm">
                All {formatCurrency(results.buildingBasis)} depreciates over{' '}
                {inputs.property_type === 'residential_rental' ? '27.5' : '39'} years
              </p>
              
              <div className="mt-4 p-3 bg-white/60 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-[#777777]">Real Property</span>
                  <div className="text-right">
                    <div className="font-semibold text-[#333333]">100%</div>
                    <div className="text-xs text-[#777777]">{formatCurrency(results.buildingBasis)}</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* After */}
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-[#0A4EAF]/20 ring-2 ring-[#0A4EAF]/10">
          <CardHeader>
            <CardTitle className="text-[#0A4EAF]">After Cost Segregation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pieData.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-white/60 rounded-lg border border-[#0A4EAF]/10">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <div>
                      <span className="text-[#333333] text-sm font-medium">{item.name}</span>
                      <div className="text-xs text-[#777777]">{item.years}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-[#333333]">{item.value}%</div>
                    <div className="text-xs text-[#777777]">{formatCurrency(item.amount)}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
