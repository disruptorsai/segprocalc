import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, DollarSign } from "lucide-react";

export default function CurrentYearView({ results, inputs }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  const chartData = [
    {
      name: 'Optimistic',
      depreciation: results.depreciation.optimistic.currentYear.total,
      savings: results.taxSavings.optimistic.currentYear,
      fill: '#f59e0b'
    },
    {
      name: 'Estimated',
      depreciation: results.depreciation.estimated.currentYear.total,
      savings: results.taxSavings.estimated.currentYear,
      fill: '#3b82f6'
    },
    {
      name: 'No Study',
      depreciation: results.depreciation.noStudy.currentYear.total,
      savings: results.taxSavings.noStudy.currentYear,
      fill: '#6b7280'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Current Year Header */}
      <div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">
          Current Tax Filing Year Depreciation
        </h3>
        <p className="text-slate-600">
          Estimated depreciation and tax savings for {inputs.current_tax_year}
        </p>
      </div>

      {/* Current Year Chart */}
      <Card className="bg-gradient-to-br from-white to-slate-50">
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="name" 
                stroke="#64748b"
                fontSize={12}
              />
              <YAxis 
                stroke="#64748b"
                fontSize={12}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip
                formatter={(value, name) => [formatCurrency(value), name === 'depreciation' ? 'Depreciation' : 'Tax Savings']}
                labelStyle={{ color: '#1e293b' }}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="depreciation" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Numeric Callouts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-amber-800">Optimistic Scenario</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-amber-900">
                {formatCurrency(results.depreciation.optimistic.currentYear.total)}
              </div>
              <div className="text-sm text-amber-700">
                Tax Savings: {formatCurrency(results.taxSavings.optimistic.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-blue-800">Estimated Scenario</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-blue-900">
                {formatCurrency(results.depreciation.estimated.currentYear.total)}
              </div>
              <div className="text-sm text-blue-700">
                Tax Savings: {formatCurrency(results.taxSavings.estimated.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 border-slate-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-700">Without Study</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-slate-800">
                {formatCurrency(results.depreciation.noStudy.currentYear.total)}
              </div>
              <div className="text-sm text-slate-600">
                Tax Savings: {formatCurrency(results.taxSavings.noStudy.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 5-Year Aggregation */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <TrendingUp className="w-5 h-5" />
            5-Year Aggregation Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Cumulative Depreciation (Years 1-5)</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-green-700">With Study (Estimated):</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.withStudy.estimated)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700">Without Study:</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.noStudy)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-green-200">
                  <span className="font-semibold text-green-800">Additional Depreciation:</span>
                  <span className="font-bold text-green-900">
                    {formatCurrency(results.fiveYearComparison.savings.estimated)}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Tax Savings Impact</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-green-700">5-Year Tax Savings:</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.savings.estimated * (inputs.federal_tax_rate / 100))}
                  </span>
                </div>
                <div className="p-3 bg-white/60 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-green-800">
                      You could save {formatCurrency(results.fiveYearComparison.savings.estimated * (inputs.federal_tax_rate / 100))} over 5 years
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}