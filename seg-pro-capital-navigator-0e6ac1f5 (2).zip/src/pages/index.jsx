
import React, { useState, useEffect } from "react";
import { CalculatorSubmission } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Info, Calculator, Download, CheckCircle } from "lucide-react";
import CurrentYearTab from "../components/calculator/CurrentYearTab";
import DepreciationOverTimeTab from "../components/calculator/DepreciationOverTimeTab";
import ReallocationTab from "../components/calculator/ReallocationTab";
import DocsTab from "../components/calculator/DocsTab";
import { calculateDepreciation, validateInputs } from "../components/calculator/calculationEngine";
import OnboardingModal from "../components/calculator/OnboardingModal"; // New import

const PROPERTY_TYPES = [
  { value: "residential_rental", label: "Residential (1-4 Units)" },
  { value: "commercial_office", label: "Commercial Office" },
  { value: "retail", label: "Retail" },
  { value: "industrial", label: "Industrial" },
  { value: "mixed_use", label: "Mixed Use" },
  { value: "hotel", label: "Hotel/Hospitality" },
  { value: "storage", label: "Storage/Warehouse" }
];

const ASSET_CLASSES = [
  { value: "single_family", label: "Single Family Home" },
  { value: "multi_unit", label: "Multi-Unit Residential" },
  { value: "commercial", label: "Commercial Building" }
];

const TAX_YEARS = Array.from({ length: 10 }, (_, i) => 2025 - i);

const InfoIcon = () => (
  <div className="w-3.5 h-3.5 bg-slate-300 text-slate-600 rounded-full flex items-center justify-center text-[10px] font-bold">
    i
  </div>
);

export default function Index() {
  const [inputs, setInputs] = useState({
    property_type: "residential_rental",
    placed_in_service_date: "2025-01-19",
    purchase_price: 1000000,
    cost_of_improvements: 0,
    estimated_land_percent: 20,
    federal_tax_rate: 37,
    current_tax_year: 2025,
    bonus_depreciation_percent: 100,
    bonus_override_100: true,
    land_value_override: null,
    asset_class: "single_family",
    lease_type: "short_term"
  });

  const [results, setResults] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [activeTab, setActiveTab] = useState("current");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const [referralCode, setReferralCode] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false); // New state

  // Extract referral code from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      setReferralCode(ref);
    }
  }, []);

  // Show onboarding on first visit or auto-calculate if returning user
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('segpro-calculator-onboarding');
    if (!hasSeenOnboarding) {
      setShowOnboarding(true);
    } else {
      // Auto-calculate if returning user
      handleCalculate();
    }
  }, []);

  const handleInputChange = (field, value) => {
    let processedValue = value;
    
    // Handle currency fields - strip formatting
    if (field === 'purchase_price' || field === 'cost_of_improvements' || field === 'land_value_override') {
      if (typeof value === 'string') {
        processedValue = parseFloat(value.replace(/[\$,\s]/g, '')) || 0;
      }
      processedValue = Math.max(0, processedValue); // Prevent negatives
    }
    
    // Handle percentage fields - clamp to 0-100
    if (field === 'estimated_land_percent' || field === 'federal_tax_rate' || field === 'bonus_depreciation_percent') {
      processedValue = Math.min(100, Math.max(0, parseFloat(value) || 0));
    }

    setInputs(prev => ({ ...prev, [field]: processedValue }));
    
    // Clear validation error for this field
    if (validationErrors[field]) {
      setValidationErrors(prev => ({ ...prev, [field]: null }));
    }

    // Auto-calculate if results exist
    if (results) {
      setTimeout(() => handleCalculate(), 100);
    }
  };

  const handleCalculate = async () => {
    setIsCalculating(true);
    
    try {
      // Validate inputs
      const errors = validateInputs(inputs);
      setValidationErrors(errors);
      
      if (Object.keys(errors).length > 0) {
        setIsCalculating(false);
        return;
      }

      // Track calculator click
      trackEvent('CalculatorClick');

      // Perform calculations
      const calculatedResults = calculateDepreciation(inputs);
      setResults(calculatedResults);
      
      // Save to database for tracking
      await CalculatorSubmission.create({
        ...inputs,
        referral_code: referralCode,
        results: calculatedResults
      });

      // Track successful submission
      trackEvent('CalculatorSubmission', { referral_code: referralCode });
      
    } catch (error) {
      console.error("Calculation error:", error);
    } finally {
      setIsCalculating(false);
    }
  };

  const trackEvent = (eventType, data = {}) => {
    console.log(`Event: ${eventType}`, { ...data, timestamp: new Date().toISOString() });
  };

  const handleTabChange = (tabValue) => {
    setActiveTab(tabValue);
    trackEvent('TabView', { tab: tabValue });
  };

  const handleGetProposal = () => {
    const subject = encodeURIComponent('Cost Segregation Study Request');
    const body = encodeURIComponent(`Hello,

I'm interested in a cost segregation study for my property:

Property Type: ${PROPERTY_TYPES.find(p => p.value === inputs.property_type)?.label}
Purchase Price: $${inputs.purchase_price.toLocaleString()}
Placed in Service: ${inputs.placed_in_service_date}

Please contact me to discuss next steps.

Best regards`);
    
    window.open(`mailto:info@segpro.com?subject=${subject}&body=${body}`, '_blank');
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  // New function for onboarding
  const handleOnboardingStart = () => {
    localStorage.setItem('segpro-calculator-onboarding', 'true');
    setShowOnboarding(false); // Close the modal
    handleCalculate(); // Trigger calculation after onboarding
  };

  return (
    <>
      <OnboardingModal
        isOpen={showOnboarding}
        onClose={() => {
          setShowOnboarding(false);
          localStorage.setItem('segpro-calculator-onboarding', 'true');
          handleCalculate(); // Trigger calculation if user closes modal
        }}
        onStart={handleOnboardingStart}
      />

      <div className="min-h-screen bg-[#EEEEEE] font-['Inter',system-ui,sans-serif]">
        <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
          <div className="grid lg:grid-cols-5 gap-8">
            {/* Input Panel */}
            <div className="lg:col-span-2">
              <Card className="bg-white rounded-2xl shadow-lg flex flex-col h-full">
                <CardContent className="p-6 space-y-6 flex-grow">
                  <div>
                    <h1 className="text-2xl font-bold text-[#333333] mb-2">Cost Segregation Calculator</h1>
                    <p className="text-[#777777] text-sm leading-relaxed">
                      Add your property details below to calculate potential accelerated depreciation utilizing a cost segregation study.
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <Button 
                      variant="outline" 
                      className="flex-1 border-[#0A4EAF] text-[#0A4EAF] hover:bg-[#0A4EAF]/5"
                      onClick={() => window.open('mailto:info@segpro.com', '_blank')}
                    >
                      Get in touch
                    </Button>
                    <Button 
                      onClick={handleGetProposal}
                      className="flex-1 bg-[#F47C00] hover:bg-[#F47C00]/90 text-white"
                    >
                      Get free proposal
                    </Button>
                  </div>

                  <p className="text-xs text-[#777777] text-center">Powered by RE COST SEG</p>

                  <div className="grid grid-cols-2 gap-x-4 gap-y-5">
                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Property Type <InfoIcon />
                      </Label>
                      <Select value={inputs.property_type} onValueChange={(value) => handleInputChange("property_type", value)}>
                        <SelectTrigger className="bg-white border-slate-300">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PROPERTY_TYPES.map((type) => (
                            <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Purchase Date <InfoIcon />
                      </Label>
                      <Input 
                        type="date" 
                        value={inputs.placed_in_service_date} 
                        onChange={(e) => handleInputChange("placed_in_service_date", e.target.value)} 
                        className="bg-white border-slate-300" 
                      />
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Asset Class <InfoIcon />
                      </Label>
                      <Select value={inputs.asset_class} onValueChange={(value) => handleInputChange("asset_class", value)}>
                        <SelectTrigger className="bg-white border-slate-300">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ASSET_CLASSES.map((asset) => (
                            <SelectItem key={asset.value} value={asset.value}>{asset.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Tax Filing Year <InfoIcon />
                      </Label>
                      <Select value={inputs.current_tax_year.toString()} onValueChange={(value) => handleInputChange("current_tax_year", parseInt(value))}>
                        <SelectTrigger className="bg-white border-slate-300">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {TAX_YEARS.map((year) => (
                            <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Depreciable Basis <InfoIcon />
                      </Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#777777]">$</span>
                        <Input 
                          type="text" 
                          value={inputs.purchase_price.toLocaleString()} 
                          onChange={(e) => handleInputChange("purchase_price", e.target.value)} 
                          className={`bg-white pl-7 border-slate-300 ${validationErrors.purchase_price ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {validationErrors.purchase_price && (
                        <p className="text-red-500 text-xs mt-1">{validationErrors.purchase_price}</p>
                      )}
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Federal Tax Rate <InfoIcon />
                      </Label>
                      <Select value={inputs.federal_tax_rate.toString()} onValueChange={(value) => handleInputChange("federal_tax_rate", parseFloat(value))}>
                        <SelectTrigger className="bg-white border-slate-300">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="37">37%</SelectItem>
                          <SelectItem value="35">35%</SelectItem>
                          <SelectItem value="32">32%</SelectItem>
                          <SelectItem value="24">24%</SelectItem>
                          <SelectItem value="22">22%</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Placed in Service <InfoIcon />
                      </Label>
                      <Input 
                        type="date" 
                        value={inputs.placed_in_service_date} 
                        onChange={(e) => handleInputChange("placed_in_service_date", e.target.value)} 
                        className="bg-white border-slate-300" 
                      />
                    </div>

                    <div>
                      <Label className="flex items-center gap-1.5 mb-2 text-[#333333] font-medium text-sm">
                        Lease Type <InfoIcon />
                      </Label>
                      <Select value={inputs.lease_type} onValueChange={(value) => handleInputChange("lease_type", value)}>
                        <SelectTrigger className="bg-white border-slate-300">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="short_term">Short term</SelectItem>
                          <SelectItem value="long_term">Long term</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <Label className="block text-[#333333] font-medium text-sm">Bonus Depreciation</Label>
                    <div className="flex items-center gap-4">
                      <div className="relative flex-1">
                        <Input 
                          type="number" 
                          min="0" 
                          max="100"
                          value={inputs.bonus_depreciation_percent} 
                          onChange={(e) => handleInputChange("bonus_depreciation_percent", e.target.value)} 
                          className="bg-[#EEEEEE] border-slate-300 pr-7" 
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[#777777]">%</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="bonus_override" 
                          checked={inputs.bonus_override_100} 
                          onCheckedChange={(checked) => handleInputChange("bonus_override_100", checked)}
                        />
                        <Label htmlFor="bonus_override" className="text-[#333333] font-medium text-sm">
                          100% Bonus
                        </Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-5">
                    <div className="flex items-center gap-2">
                      <Switch 
                        id="advanced-fields" 
                        checked={showAdvanced} 
                        onCheckedChange={setShowAdvanced} 
                      />
                      <Label htmlFor="advanced-fields" className="text-[#0A4EAF] font-medium text-sm">
                        Advanced fields
                      </Label>
                    </div>
                    <button className="flex items-center gap-2 text-[#0A4EAF] font-medium text-sm hover:underline">
                      <Info size={16} />
                      Disclaimer
                    </button>
                  </div>

                  {showAdvanced && (
                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200">
                      <div>
                        <Label className="block mb-2 text-[#333333] font-medium text-sm">
                          Land Percentage
                        </Label>
                        <div className="relative">
                          <Input 
                            type="number" 
                            min="0" 
                            max="100"
                            value={inputs.estimated_land_percent} 
                            onChange={(e) => handleInputChange("estimated_land_percent", e.target.value)} 
                            className="bg-white border-slate-300 pr-7" 
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[#777777]">%</span>
                        </div>
                      </div>
                      <div>
                        <Label className="block mb-2 text-[#333333] font-medium text-sm">
                          Cost of Improvements
                        </Label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#777777]">$</span>
                          <Input 
                            type="text" 
                            value={inputs.cost_of_improvements.toLocaleString()} 
                            onChange={(e) => handleInputChange("cost_of_improvements", e.target.value)} 
                            className="bg-white border-slate-300 pl-7" 
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
                <div className="p-6 border-t border-slate-200 bg-slate-50 rounded-b-2xl">
                  <Button 
                    onClick={handleCalculate}
                    disabled={isCalculating}
                    className="w-full bg-[#0A4EAF] hover:bg-[#0A4EAF]/90 text-white text-lg py-6"
                  >
                    <Calculator className="w-5 h-5 mr-3" />
                    {isCalculating ? "Calculating..." : "Recalculate Estimate"}
                  </Button>
                </div>
              </Card>
            </div>

            {/* Results Panel with Sidebar Tabs */}
            <div className="lg:col-span-3">
              <Card className="bg-white rounded-2xl shadow-lg">
                <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
                  <div className="flex">
                    {/* Sidebar Navigation */}
                    <div className="w-56 border-r border-slate-200">
                      <TabsList className="flex flex-col h-full w-full bg-transparent p-0">
                        <TabsTrigger 
                          value="current" 
                          className="w-full justify-start px-6 py-4 text-left data-[state=active]:bg-[#0A4EAF]/10 data-[state=active]:text-[#0A4EAF] data-[state=active]:border-r-2 data-[state=active]:border-[#0A4EAF] rounded-none"
                        >
                          <div>
                            <div className="font-medium">Current Tax Year</div>
                            <div className="text-xs text-[#777777]">Year 1 analysis</div>
                          </div>
                        </TabsTrigger>
                        <TabsTrigger 
                          value="overtime" 
                          className="w-full justify-start px-6 py-4 text-left data-[state=active]:bg-[#0A4EAF]/10 data-[state=active]:text-[#0A4EAF] data-[state=active]:border-r-2 data-[state=active]:border-[#0A4EAF] rounded-none"
                        >
                          <div>
                            <div className="font-medium">Depreciation Over Time</div>
                            <div className="text-xs text-[#777777]">15-year projection</div>
                          </div>
                        </TabsTrigger>
                        <TabsTrigger 
                          value="reallocation" 
                          className="w-full justify-start px-6 py-4 text-left data-[state=active]:bg-[#0A4EAF]/10 data-[state=active]:text-[#0A4EAF] data-[state=active]:border-r-2 data-[state=active]:border-[#0A4EAF] rounded-none"
                        >
                          <div>
                            <div className="font-medium">Reallocation</div>
                            <div className="text-xs text-[#777777]">Asset breakdown</div>
                          </div>
                        </TabsTrigger>
                        <TabsTrigger 
                          value="docs" 
                          className="w-full justify-start px-6 py-4 text-left data-[state=active]:bg-[#0A4EAF]/10 data-[state=active]:text-[#0A4EAF] data-[state=active]:border-r-2 data-[state=active]:border-[#0A4EAF] rounded-none"
                        >
                          <div>
                            <div className="font-medium">Docs</div>
                            <div className="text-xs text-[#777777]">Acceptance & Export</div>
                          </div>
                        </TabsTrigger>
                      </TabsList>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1">
                      <TabsContent value="current" className="m-0 p-6">
                        <CurrentYearTab results={results} inputs={inputs} isCalculating={isCalculating} />
                      </TabsContent>
                      <TabsContent value="overtime" className="m-0 p-6">
                        <DepreciationOverTimeTab results={results} inputs={inputs} isCalculating={isCalculating} trackEvent={trackEvent} />
                      </TabsContent>
                      <TabsContent value="reallocation" className="m-0 p-6">
                        <ReallocationTab results={results} inputs={inputs} isCalculating={isCalculating} />
                      </TabsContent>
                      <TabsContent value="docs" className="m-0 p-6">
                        <DocsTab results={results} inputs={inputs} />
                      </TabsContent>
                    </div>
                  </div>
                </Tabs>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
