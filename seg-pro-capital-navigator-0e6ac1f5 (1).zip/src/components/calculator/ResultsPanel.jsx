import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import CurrentYearView from "./CurrentYearView";
import DepreciationOverTimeView from "./DepreciationOverTimeView";
import ReallocationView from "./ReallocationView";

const TabButton = ({ label, value, activeTab, setActiveTab }) => (
    <button
        onClick={() => setActiveTab(value)}
        className={`px-4 py-3 text-center font-medium transition-all duration-200 w-full
            ${activeTab === value ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-800'}`
        }
    >
        {label}
    </button>
);

export default function ResultsPanel({ results, inputs, activeTab, setActiveTab, isCalculating }) {
  const renderContent = () => {
    if (isCalculating && !results) {
      return (
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-800">Calculating...</h3>
          </div>
        </div>
      );
    }

    if (!results) {
        return (
             <div className="flex items-center justify-center h-96">
                <p className="text-slate-500">Enter your details and click "Get free proposal" to see your results.</p>
             </div>
        );
    }
    
    switch(activeTab) {
        case 'current': return <CurrentYearView results={results} inputs={inputs} />;
        case 'overtime': return <DepreciationOverTimeView results={results} inputs={inputs} />;
        case 'reallocation': return <ReallocationView results={results} inputs={inputs} />;
        default: return null;
    }
  };

  return (
    <Card className="bg-white rounded-2xl shadow-lg">
      <div className="flex border-b border-slate-200">
          <TabButton label="Current Tax Year" value="current" activeTab={activeTab} setActiveTab={setActiveTab} />
          <TabButton label="Depreciation Over Time" value="overtime" activeTab={activeTab} setActiveTab={setActiveTab} />
          <TabButton label="Reallocation" value="reallocation" activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
      <CardContent className="p-6">
          {renderContent()}
      </CardContent>
    </Card>
  );
}