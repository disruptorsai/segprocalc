import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, DollarSign, Loader2 } from "lucide-react";

export default function CurrentYearTab({ results, inputs, isCalculating }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  if (isCalculating) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#0A4EAF] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#333333] mb-2">Calculating Your Savings</h3>
          <p className="text-[#777777]">Analyzing your property for optimal depreciation strategy...</p>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-16 h-16 bg-[#EEEEEE] rounded-full flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-8 h-8 text-[#777777]" />
          </div>
          <h3 className="text-lg font-semibold text-[#333333] mb-2">Ready to Calculate</h3>
          <p className="text-[#777777]">Enter your property details to see your potential tax benefits.</p>
        </div>
      </div>
    );
  }

  const chartData = [
    {
      name: 'No Study',
      depreciation: results.depreciation.noStudy.currentYear.total,
      savings: results.taxSavings.noStudy.currentYear,
      fill: '#CBD5E1'
    },
    {
      name: 'Estimated',
      depreciation: results.depreciation.estimated.currentYear.total,
      savings: results.taxSavings.estimated.currentYear,
      fill: '#0A4EAF'
    },
    {
      name: 'Optimistic',
      depreciation: results.depreciation.optimistic.currentYear.total,
      savings: results.taxSavings.optimistic.currentYear,
      fill: '#F47C00'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#333333] mb-2">
          Current Tax Filing Year Depreciation
        </h2>
        <p className="text-[#777777]">
          Estimated depreciation and tax savings for {inputs.current_tax_year}
        </p>
      </div>

      {/* Current Year Chart */}
      <Card className="bg-gradient-to-br from-white to-slate-50 border-slate-200">
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="name" 
                stroke="#777777"
                fontSize={12}
                tick={{ fill: '#777777' }}
              />
              <YAxis 
                stroke="#777777"
                fontSize={12}
                tick={{ fill: '#777777' }}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip
                formatter={(value, name) => [formatCurrency(value), name === 'depreciation' ? 'Depreciation' : 'Tax Savings']}
                labelStyle={{ color: '#333333' }}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Bar 
                dataKey="depreciation" 
                radius={[4, 4, 0, 0]}
                stroke="#fff"
                strokeWidth={1}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Numeric Callouts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 border-slate-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[#777777]">Without Study</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-[#333333]">
                {formatCurrency(results.depreciation.noStudy.currentYear.total)}
              </div>
              <div className="text-sm text-[#777777]">
                Tax Savings: {formatCurrency(results.taxSavings.noStudy.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-[#0A4EAF]/20 ring-2 ring-[#0A4EAF]/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[#0A4EAF]">Estimated Scenario</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-[#0A4EAF]">
                {formatCurrency(results.depreciation.estimated.currentYear.total)}
              </div>
              <div className="text-sm text-[#0A4EAF]/80">
                Tax Savings: {formatCurrency(results.taxSavings.estimated.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-[#F47C00]/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[#F47C00]">Optimistic Scenario</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-[#F47C00]">
                {formatCurrency(results.depreciation.optimistic.currentYear.total)}
              </div>
              <div className="text-sm text-[#F47C00]/80">
                Tax Savings: {formatCurrency(results.taxSavings.optimistic.currentYear)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 5-Year Aggregation */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <TrendingUp className="w-5 h-5" />
            5-Year Aggregation Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Cumulative Depreciation (Years 1-5)</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-green-700">With Study (Estimated):</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.withStudy.estimated)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700">Without Study:</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.noStudy)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-green-200">
                  <span className="font-semibold text-green-800">Additional Depreciation:</span>
                  <span className="font-bold text-green-900">
                    {formatCurrency(results.fiveYearComparison.savings.estimated)}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-green-800 mb-3">Tax Savings Impact</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-green-700">5-Year Tax Savings:</span>
                  <span className="font-semibold text-green-900">
                    {formatCurrency(results.fiveYearComparison.taxSavings.estimated)}
                  </span>
                </div>
                <div className="p-4 bg-white/60 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-800">
                      You could save <strong>{formatCurrency(results.fiveYearComparison.taxSavings.estimated)}</strong> over 5 years
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}