import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Info } from "lucide-react";

const PROPERTY_TYPES = [
  { value: "residential_rental", label: "Residential (1-4 Units)" },
  { value: "commercial_office", label: "Commercial Office" },
  { value: "retail", label: "Retail" },
  { value: "industrial", label: "Industrial" },
  { value: "mixed_use", label: "Mixed Use" },
  { value: "hotel", label: "Hotel/Hospitality" },
  { value: "storage", label: "Storage/Warehouse" }
];

const ASSET_CLASSES = [
  { value: "single_family", label: "Single Family Home" },
  { value: "multi_unit", label: "Multi-Unit Residential" },
  { value: "commercial", label: "Commercial Building" }
];

const TAX_YEARS = Array.from({ length: 10 }, (_, i) => 2025 - i);

const InfoIcon = () => (
    <div className="w-3.5 h-3.5 bg-slate-200 text-slate-500 rounded-full flex items-center justify-center text-xs font-bold -mt-px">
        i
    </div>
);

export default function InputPanel({ inputs, onInputChange, onCalculate, isCalculating }) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  return (
    <Card className="bg-white rounded-2xl shadow-lg p-6 space-y-6">
        <div>
            <h1 className="text-2xl font-bold text-slate-800">Cost Segregation Calculator</h1>
            <p className="text-slate-500 mt-2">
                Add your property details below to calculate potential accelerated depreciation utilizing a cost segregation study.
            </p>
        </div>

        <div className="flex gap-3">
          <Button variant="outline" className="w-full border-slate-300 text-slate-700 hover:bg-slate-50">
            Get in touch
          </Button>
          <Button onClick={onCalculate} disabled={isCalculating} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            {isCalculating ? "Calculating..." : "Get free proposal"}
          </Button>
        </div>

        <p className="text-xs text-slate-400 text-center">Powered by RE COST SEG</p>

        <div className="grid grid-cols-2 gap-x-4 gap-y-5">
            <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Property Type <InfoIcon /></Label>
              <Select value={inputs.property_type} onValueChange={(value) => onInputChange("property_type", value)}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>{PROPERTY_TYPES.map((type) => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Purchase Date <InfoIcon /></Label>
              <Input type="date" value={inputs.placed_in_service_date} onChange={(e) => onInputChange("placed_in_service_date", e.target.value)} className="bg-white" />
            </div>
             <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Asset Class <InfoIcon /></Label>
              <Select defaultValue="single_family">
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>{ASSET_CLASSES.map((asset) => <SelectItem key={asset.value} value={asset.value}>{asset.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
             <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Tax Filing Year <InfoIcon /></Label>
              <Select value={inputs.current_tax_year.toString()} onValueChange={(value) => onInputChange("current_tax_year", parseInt(value))}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>{TAX_YEARS.map((year) => <SelectItem key={year} value={year.toString()}>{year}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Depreciable Basis <InfoIcon /></Label>
               <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                <Input type="text" value={inputs.purchase_price.toLocaleString()} onChange={(e) => { const value = e.target.value.replace(/,/g, ''); onInputChange("purchase_price", parseFloat(value) || 0); }} className="bg-white pl-7" />
              </div>
            </div>
            <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Federal Tax Rate <InfoIcon /></Label>
              <Select value={inputs.federal_tax_rate.toString()} onValueChange={(value) => onInputChange("federal_tax_rate", parseFloat(value))}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="37">37%</SelectItem><SelectItem value="35">35%</SelectItem><SelectItem value="32">32%</SelectItem><SelectItem value="24">24%</SelectItem><SelectItem value="22">22%</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Placed in Service <InfoIcon /></Label>
              <Input type="date" value={inputs.placed_in_service_date} onChange={(e) => onInputChange("placed_in_service_date", e.target.value)} className="bg-white" />
            </div>
             <div>
              <Label className="flex items-center gap-1.5 mb-1.5 text-slate-600 font-medium">Lease Type <InfoIcon /></Label>
              <Select defaultValue="short_term">
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="short_term">Short term</SelectItem><SelectItem value="long_term">Long term</SelectItem></SelectContent>
              </Select>
            </div>
        </div>
        
        <div className="space-y-3">
             <Label className="block text-slate-600 font-medium">Bonus Depreciation</Label>
             <div className="flex items-center gap-4">
               <div className="relative flex-1">
                 <Input type="text" value={inputs.bonus_depreciation_percent} onChange={(e) => onInputChange("bonus_depreciation_percent", parseFloat(e.target.value) || 0)} className="bg-slate-100 border-slate-200 pr-7" />
                 <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">%</span>
               </div>
               <div className="flex items-center space-x-2">
                <Checkbox id="bonus_override" checked={inputs.bonus_override_100} onCheckedChange={(checked) => onInputChange("bonus_override_100", checked)}/>
                <Label htmlFor="bonus_override" className="text-slate-600 font-medium">100% Bonus</Label>
              </div>
             </div>
        </div>

        <div className="flex items-center justify-between border-t border-slate-200 pt-5">
            <div className="flex items-center gap-2">
                <Switch id="advanced-fields" checked={showAdvanced} onCheckedChange={setShowAdvanced} />
                <Label htmlFor="advanced-fields" className="text-blue-600 font-medium">Advanced fields</Label>
            </div>
            <button className="flex items-center gap-2 text-blue-600 font-medium">
                <Info size={16} />
                Disclaimer
            </button>
        </div>
    </Card>
  );
}