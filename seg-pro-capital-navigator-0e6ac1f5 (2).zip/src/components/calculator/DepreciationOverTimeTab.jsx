import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Slider } from "@/components/ui/slider";
import { Loader2 } from "lucide-react";

export default function DepreciationOverTimeTab({ results, inputs, isCalculating, trackEvent }) {
  const [selectedYear, setSelectedYear] = useState(1);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  const handleSliderChange = (value) => {
    setSelectedYear(value[0]);
    if (trackEvent) {
      trackEvent('SliderChange', { year: value[0] });
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowLeft' && selectedYear > 1) {
      handleSliderChange([selectedYear - 1]);
    } else if (e.key === 'ArrowRight' && selectedYear < 15) {
      handleSliderChange([selectedYear + 1]);
    }
  };

  if (isCalculating) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#0A4EAF] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#333333]">Calculating...</h3>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-[#777777]">Enter your details to see the 15-year depreciation projection.</p>
      </div>
    );
  }

  // Prepare chart data
  const chartData = Array.from({ length: 15 }, (_, index) => {
    const year = index + 1;
    const withStudyData = results.depreciation.estimated.yearlyDepreciation[index];
    const noStudyData = results.depreciation.noStudy.yearlyDepreciation[index];
    
    return {
      year,
      withStudy: withStudyData.total,
      noStudy: noStudyData.total,
      withStudyCumulative: withStudyData.cumulative,
      noStudyCumulative: noStudyData.cumulative
    };
  });

  const selectedYearData = chartData[selectedYear - 1];
  const savings = selectedYearData.withStudy - selectedYearData.noStudy;
  const taxSavings = savings * (inputs.federal_tax_rate / 100);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-[#333333] mb-2">
          Depreciation Over First 15 Years
        </h2>
        <p className="text-[#777777]">
          Compare annual depreciation schedules with and without cost segregation study
        </p>
      </div>

      {/* Chart */}
      <Card className="bg-gradient-to-br from-white to-slate-50 border-slate-200">
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="year" 
                stroke="#777777"
                fontSize={12}
                tick={{ fill: '#777777' }}
              />
              <YAxis 
                stroke="#777777"
                fontSize={12}
                tick={{ fill: '#777777' }}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip
                formatter={(value, name) => [
                  formatCurrency(value), 
                  name === 'withStudy' ? 'With Cost Seg Study' : 'No Study'
                ]}
                labelFormatter={(label) => `Year ${label}`}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="withStudy" 
                stroke="#0A4EAF" 
                strokeWidth={3}
                dot={{ fill: '#0A4EAF', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#0A4EAF', strokeWidth: 2, fill: '#0A4EAF' }}
              />
              <Line 
                type="monotone" 
                dataKey="noStudy" 
                stroke="#CBD5E1" 
                strokeWidth={3}
                strokeDasharray="8 8"
                dot={{ fill: '#CBD5E1', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#CBD5E1', strokeWidth: 2, fill: '#CBD5E1' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Year Slider */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-[#0A4EAF]/20">
        <CardHeader>
          <CardTitle className="text-[#0A4EAF]">Year {selectedYear} Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm font-medium text-[#0A4EAF]">Select Year:</span>
              <span className="text-lg font-bold text-[#0A4EAF]">Year {selectedYear}</span>
            </div>
            <div 
              className="w-full"
              onKeyDown={handleKeyDown}
              tabIndex={0}
              role="slider"
              aria-valuemin={1}
              aria-valuemax={15}
              aria-valuenow={selectedYear}
              aria-label={`Year selector, currently year ${selectedYear}`}
            >
              <Slider
                value={[selectedYear]}
                onValueChange={handleSliderChange}
                max={15}
                min={1}
                step={1}
                className="w-full [&_[role=slider]]:bg-[#0A4EAF] [&_[role=slider]]:border-[#0A4EAF] [&_.bg-primary]:bg-[#0A4EAF]"
              />
            </div>
            <div className="flex justify-between text-xs text-[#0A4EAF]/70 mt-2">
              <span>Year 1</span>
              <span>Year 15</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/60 rounded-lg p-4 border border-[#0A4EAF]/10">
              <div className="text-sm text-[#0A4EAF] mb-1">With Cost Seg Study</div>
              <div className="text-xl font-bold text-[#0A4EAF]">
                {formatCurrency(selectedYearData.withStudy)}
              </div>
            </div>
            
            <div className="bg-white/60 rounded-lg p-4 border border-slate-200">
              <div className="text-sm text-[#777777] mb-1">Without Study</div>
              <div className="text-xl font-bold text-[#333333]">
                {formatCurrency(selectedYearData.noStudy)}
              </div>
            </div>
            
            <div className="bg-white/60 rounded-lg p-4 border border-green-200">
              <div className="text-sm text-green-700 mb-1">Additional Tax Savings</div>
              <div className="text-xl font-bold text-green-900">
                {formatCurrency(Math.round(taxSavings))}
              </div>
            </div>
          </div>

          <div className="text-sm text-[#0A4EAF] bg-white/40 rounded-lg p-3 border border-[#0A4EAF]/20">
            <strong>Year {selectedYear} Analysis:</strong> With cost segregation, you would have{' '}
            <strong>{formatCurrency(Math.round(savings))}</strong> more in depreciation deductions, resulting in{' '}
            <strong>{formatCurrency(Math.round(taxSavings))}</strong> additional tax savings compared to traditional depreciation.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}