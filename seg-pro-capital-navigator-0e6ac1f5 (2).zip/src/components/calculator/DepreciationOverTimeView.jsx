import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Slider } from "@/components/ui/slider";

export default function DepreciationOverTimeView({ results, inputs }) {
  const [selectedYear, setSelectedYear] = useState(1);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  // Prepare chart data
  const chartData = Array.from({ length: 15 }, (_, index) => {
    const year = index + 1;
    const withStudyData = results.depreciation.estimated.yearlyDepreciation[index];
    const noStudyData = results.depreciation.noStudy.yearlyDepreciation[index];
    
    return {
      year,
      withStudy: withStudyData.total,
      noStudy: noStudyData.total,
      withStudyCumulative: withStudyData.cumulative,
      noStudyCumulative: noStudyData.cumulative
    };
  });

  const selectedYearData = chartData[selectedYear - 1];
  const savings = selectedYearData.withStudy - selectedYearData.noStudy;
  const taxSavings = savings * (inputs.federal_tax_rate / 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">
          Depreciation Over First 15 Years
        </h3>
        <p className="text-slate-600">
          Compare depreciation schedules with and without cost segregation study
        </p>
      </div>

      {/* Chart */}
      <Card className="bg-gradient-to-br from-white to-slate-50">
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="year" 
                stroke="#64748b"
                fontSize={12}
              />
              <YAxis 
                stroke="#64748b"
                fontSize={12}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip
                formatter={(value, name) => [
                  formatCurrency(value), 
                  name === 'withStudy' ? 'With Cost Seg Study' : 'No Study'
                ]}
                labelFormatter={(label) => `Year ${label}`}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="withStudy" 
                stroke="#3b82f6" 
                strokeWidth={3}
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#3b82f6', strokeWidth: 2 }}
              />
              <Line 
                type="monotone" 
                dataKey="noStudy" 
                stroke="#6b7280" 
                strokeWidth={3}
                strokeDasharray="5 5"
                dot={{ fill: '#6b7280', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#6b7280', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Year Slider */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-900">Year {selectedYear} Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm font-medium text-blue-800">Select Year:</span>
              <span className="text-lg font-bold text-blue-900">Year {selectedYear}</span>
            </div>
            <Slider
              value={[selectedYear]}
              onValueChange={(value) => setSelectedYear(value[0])}
              max={15}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-blue-600 mt-2">
              <span>Year 1</span>
              <span>Year 15</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/60 rounded-lg p-4">
              <div className="text-sm text-blue-700 mb-1">With Cost Seg Study</div>
              <div className="text-xl font-bold text-blue-900">
                {formatCurrency(selectedYearData.withStudy)}
              </div>
            </div>
            
            <div className="bg-white/60 rounded-lg p-4">
              <div className="text-sm text-slate-600 mb-1">Without Study</div>
              <div className="text-xl font-bold text-slate-800">
                {formatCurrency(selectedYearData.noStudy)}
              </div>
            </div>
            
            <div className="bg-white/60 rounded-lg p-4">
              <div className="text-sm text-green-700 mb-1">Additional Savings</div>
              <div className="text-xl font-bold text-green-900">
                {formatCurrency(taxSavings)}
              </div>
            </div>
          </div>

          <div className="text-sm text-blue-700 bg-white/40 rounded-lg p-3">
            <strong>Year {selectedYear} Analysis:</strong> With cost segregation, you would have 
            {formatCurrency(savings)} more in depreciation deductions, resulting in 
            {formatCurrency(taxSavings)} additional tax savings compared to traditional depreciation.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}