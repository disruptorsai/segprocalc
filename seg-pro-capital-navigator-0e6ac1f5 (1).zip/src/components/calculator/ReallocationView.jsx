import React, { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Button } from "@/components/ui/button";

const COLORS = {
  personalProperty: '#174A7C', // Dark Blue for Personal Property
  siteImprovements: '#60A5FA', // Medium Blue for Site Improvements
  realProperty: '#BFDBFE'     // Light Blue for Real Property
};

const CATEGORY_LABELS = {
  personalProperty: 'Personal Property',
  siteImprovements: 'Site Improvements',
  realProperty: 'Real Property'
};

export default function ReallocationView({ results, inputs }) {
  const [viewMode, setViewMode] = useState('optimal'); // 'optimal' or 'baseline'

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value || 0);
  };

  const scenario = viewMode === 'optimal' ? 'optimistic' : 'estimated';
  const currentAllocation = results.allocations[scenario];
  
  const pieData = [
    {
      name: CATEGORY_LABELS.personalProperty,
      value: currentAllocation.percentages.personalProperty,
      amount: currentAllocation.amounts.personalProperty,
      color: COLORS.personalProperty
    },
    {
      name: CATEGORY_LABELS.siteImprovements,
      value: currentAllocation.percentages.siteImprovements,
      amount: currentAllocation.amounts.siteImprovements,
      color: COLORS.siteImprovements
    },
    {
      name: CATEGORY_LABELS.realProperty,
      value: currentAllocation.percentages.realProperty,
      amount: currentAllocation.amounts.realProperty,
      color: COLORS.realProperty
    }
  ];

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
    if (percent === 0) return null;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" className="font-bold text-base pointer-events-none">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="text-center">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          Breakout of property into recovery periods
        </h3>
        <div className="flex justify-center items-center gap-x-4 sm:gap-x-6">
          {pieData.map((entry, index) => (
            <div key={`legend-${index}`} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-sm text-slate-600">{entry.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-grow relative -mt-4">
        <div className="absolute inset-0 flex items-center justify-center opacity-10 -z-10">
          <svg width="80%" height="80%" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path d="M50 180 L50 70 L100 20 L150 70 L150 180 Z" stroke="#cbd5e1" strokeWidth="2" fill="none"/>
            <path d="M75 180 L75 100 L125 100 L125 180" stroke="#cbd5e1" strokeWidth="2" fill="none"/>
          </svg>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomizedLabel}
              innerRadius={90}
              outerRadius={140}
              paddingAngle={3}
              dataKey="value"
              startAngle={90}
              endAngle={450}
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} stroke="#f8fafc" strokeWidth={4}/>
              ))}
            </Pie>
            <Tooltip
              formatter={(value, name, props) => [`${formatCurrency(props.payload.amount)} (${value.toFixed(0)}%)`, name]}
              contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0',
                  borderRadius: '12px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="flex justify-end pt-2 -mt-8">
         <div className="flex items-center p-1 bg-slate-200/70 rounded-lg">
            <Button
              variant={viewMode === 'baseline' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('baseline')}
              className={`rounded-md transition-all duration-200 ${viewMode === 'baseline' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-600'}`}
            >
              Baseline
            </Button>
            <Button
              variant={viewMode === 'optimal' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('optimal')}
              className={`rounded-md transition-all duration-200 ${viewMode === 'optimal' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-600'}`}
            >
              Optimal
            </Button>
         </div>
      </div>
    </div>
  );
}