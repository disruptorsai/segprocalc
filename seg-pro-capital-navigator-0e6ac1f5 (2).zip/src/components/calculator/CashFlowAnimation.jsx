
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Card } from "@/components/ui/card";

const Typewriter = ({ text, delay, className }) => {
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    setDisplayedText(''); // Reset on text change
    let i = 0;
    const interval = setInterval(() => {
      setDisplayedText(prev => prev + text.charAt(i));
      i++;
      if (i > text.length) clearInterval(interval);
    }, delay);
    return () => clearInterval(interval);
  }, [text, delay]);

  return <span className={className}>{displayedText}</span>;
};

const CashFlowAnimation = ({ taxSavings }) => {
  const [step, setStep] = useState(0);
  const [key, setKey] = useState(0); // Add a key to force re-render and re-run animation

  useEffect(() => {
    // This effect will re-trigger the animation whenever taxSavings changes.
    setKey(prevKey => prevKey + 1);
  }, [taxSavings]);

  useEffect(() => {
    setStep(0); // Reset step when key changes
    
    const timers = [
      setTimeout(() => setStep(1), 500),   // Title Reveal
      setTimeout(() => setStep(2), 1500),  // BEFORE panel
      setTimeout(() => setStep(3), 4000),  // Arrow
      setTimeout(() => setStep(4), 5000),  // AFTER panel
    ];
    
    return () => timers.forEach(clearTimeout);
  }, [key]); // Re-run effect when key changes

  const formatCurrency = (value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5, staggerChildren: 0.2 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm overflow-hidden">
      <AnimatePresence>
        <motion.div
          key={key}
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="p-6"
        >
          <motion.h3 variants={itemVariants} className="text-lg font-bold text-center text-[#333333] mb-6">
            Cost Segregation — Cash Flow Comparison
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 md:gap-8 items-start relative">
            
            {/* BEFORE PANEL */}
            <AnimatePresence>
              {step >= 2 && (
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                  <h4 className="font-semibold text-red-600 mb-4">BEFORE Cost Segregation Analysis</h4>
                  <div className="flex items-center gap-4">
                    <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="w-24 h-24 bg-slate-800 rounded-full flex-shrink-0 flex items-center justify-center text-center text-white p-2">
                      <div>
                        <div className="font-bold">39 Year</div>
                        <div className="text-sm">100%</div>
                      </div>
                    </motion.div>
                    <div>
                      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.5 } }} className="text-sm text-slate-600">• Static Depreciation Schedule</motion.p>
                      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.8 } }} className="text-sm text-slate-600">• No Change in Cash Flow</motion.p>
                    </div>
                  </div>
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 1.2 } }} className="mt-4 text-red-600 font-bold text-lg">
                    + $0
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
            
            {/* ARROW */}
            <AnimatePresence>
            {step >= 3 && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 hidden md:block">
                    <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.2 }}>
                        <ArrowRight className="w-10 h-10 text-slate-400" />
                    </motion.div>
                </div>
            )}
            </AnimatePresence>

            {/* AFTER PANEL */}
            <AnimatePresence>
              {step >= 4 && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                  <h4 className="font-semibold text-green-600 mb-4">AFTER Cost Segregation Analysis</h4>
                  <div className="flex items-center gap-4">
                     <div className="w-24 h-24 rounded-full flex-shrink-0 relative">
                        <svg viewBox="0 0 36 36" className="w-full h-full">
                            <motion.path
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#BFDBFE" // Real Property
                                strokeWidth="4"
                            />
                            <motion.path
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#60A5FA" // Site Improvements
                                strokeWidth="4"
                                strokeDasharray="25, 100" // 25% for site
                                initial={{ strokeDashoffset: 100 }}
                                animate={{ strokeDashoffset: 0 }}
                                transition={{ duration: 0.8, delay: 0.5, ease: "easeInOut" }}
                            />
                             <motion.path
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#F47C00" // Personal Property
                                strokeWidth="4"
                                strokeDasharray="15, 100" // 15% for personal
                                initial={{ strokeDashoffset: 100 }}
                                animate={{ strokeDashoffset: 0 }}
                                transition={{ duration: 0.8, delay: 0.7, ease: "easeInOut" }}
                            />
                        </svg>
                     </div>
                    <div>
                      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 1.0 } }} className="text-sm text-slate-600">• Accelerated Depreciation</motion.p>
                      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 1.3 } }} className="text-sm text-slate-600">• Increased Cash Flow</motion.p>
                    </div>
                  </div>
                   <div className="mt-4 text-green-600 font-bold text-lg">
                    <AnimatePresence>
                     {step >= 4 && (
                        <span>
                            + <Typewriter text={formatCurrency(taxSavings)} delay={50} />
                        </span>
                     )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </AnimatePresence>
    </Card>
  );
};

export default CashFlowAnimation;
