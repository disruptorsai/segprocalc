// Cost Segregation Calculation Engine

const PROPERTY_ALLOCATIONS = {
  residential_rental: {
    estimated: { personalProperty: 15, siteImprovements: 10, realProperty: 75 },
    optimistic: { personalProperty: 25, siteImprovements: 15, realProperty: 60 }
  },
  commercial_office: {
    estimated: { personalProperty: 20, siteImprovements: 15, realProperty: 65 },
    optimistic: { personalProperty: 30, siteImprovements: 20, realProperty: 50 }
  },
  retail: {
    estimated: { personalProperty: 25, siteImprovements: 15, realProperty: 60 },
    optimistic: { personalProperty: 35, siteImprovements: 20, realProperty: 45 }
  },
  industrial: {
    estimated: { personalProperty: 30, siteImprovements: 20, realProperty: 50 },
    optimistic: { personalProperty: 40, siteImprovements: 25, realProperty: 35 }
  },
  mixed_use: {
    estimated: { personalProperty: 18, siteImprovements: 12, realProperty: 70 },
    optimistic: { personalProperty: 28, siteImprovements: 17, realProperty: 55 }
  },
  hotel: {
    estimated: { personalProperty: 35, siteImprovements: 15, realProperty: 50 },
    optimistic: { personalProperty: 45, siteImprovements: 20, realProperty: 35 }
  },
  storage: {
    estimated: { personalProperty: 15, siteImprovements: 25, realProperty: 60 },
    optimistic: { personalProperty: 25, siteImprovements: 30, realProperty: 45 }
  }
};

const RECOVERY_PERIODS = {
  personalProperty: 5,  // 5-year property
  siteImprovements: 15, // 15-year property
  realProperty: {
    residential: 27.5,
    commercial: 39
  }
};

export function calculateDepreciation(inputs) {
  const {
    property_type,
    purchase_price,
    cost_of_improvements,
    estimated_land_percent,
    land_value_override,
    federal_tax_rate,
    bonus_depreciation_percent,
    bonus_override_100
  } = inputs;

  // Calculate land value and building basis
  const landValue = land_value_override || (purchase_price * (estimated_land_percent / 100));
  const buildingBasis = purchase_price - landValue + cost_of_improvements;

  // Determine if residential or commercial
  const isResidential = property_type === 'residential_rental';
  const realPropertyLife = isResidential ? 27.5 : 39;

  // Get allocation percentages
  const allocations = PROPERTY_ALLOCATIONS[property_type];
  const estimatedAllocation = allocations.estimated;
  const optimisticAllocation = allocations.optimistic;

  // Calculate allocated amounts
  const calculateAllocatedAmounts = (allocation) => {
    return {
      personalProperty: buildingBasis * (allocation.personalProperty / 100),
      siteImprovements: buildingBasis * (allocation.siteImprovements / 100),
      realProperty: buildingBasis * (allocation.realProperty / 100)
    };
  };

  const estimatedAmounts = calculateAllocatedAmounts(estimatedAllocation);
  const optimisticAmounts = calculateAllocatedAmounts(optimisticAllocation);

  // Calculate depreciation for each scenario
  const calculateScenarioDepreciation = (amounts, isNoStudy = false) => {
    if (isNoStudy) {
      // No study: all building basis depreciates over real property life
      const annualDepreciation = buildingBasis / realPropertyLife;
      return {
        currentYear: {
          personalProperty: 0,
          siteImprovements: 0,
          realProperty: annualDepreciation,
          total: annualDepreciation
        },
        yearlyDepreciation: Array.from({ length: 15 }, (_, year) => ({
          year: year + 1,
          personalProperty: 0,
          siteImprovements: 0,
          realProperty: annualDepreciation,
          total: annualDepreciation
        })),
        fiveYearTotal: annualDepreciation * 5
      };
    }

    // Calculate bonus depreciation
    const bonusRate = bonus_override_100 ? 1.0 : (bonus_depreciation_percent / 100);
    
    // Year 1 depreciation with bonus
    const year1PP = amounts.personalProperty * bonusRate + 
                   amounts.personalProperty * (1 - bonusRate) * (1 / RECOVERY_PERIODS.personalProperty);
    const year1SI = amounts.siteImprovements * bonusRate + 
                   amounts.siteImprovements * (1 - bonusRate) * (1 / RECOVERY_PERIODS.siteImprovements);
    const year1RP = amounts.realProperty / realPropertyLife;

    // Calculate yearly depreciation for 15 years
    const yearlyDepreciation = [];
    let cumulativeDepreciation = 0;

    for (let year = 1; year <= 15; year++) {
      let yearPP, yearSI, yearRP;

      if (year === 1) {
        yearPP = year1PP;
        yearSI = year1SI;
        yearRP = year1RP;
      } else {
        // Remaining depreciation after bonus
        const remainingPP = amounts.personalProperty * (1 - bonusRate);
        const remainingSI = amounts.siteImprovements * (1 - bonusRate);
        
        yearPP = year <= RECOVERY_PERIODS.personalProperty ? remainingPP / RECOVERY_PERIODS.personalProperty : 0;
        yearSI = year <= RECOVERY_PERIODS.siteImprovements ? remainingSI / RECOVERY_PERIODS.siteImprovements : 0;
        yearRP = amounts.realProperty / realPropertyLife;
      }

      const yearTotal = yearPP + yearSI + yearRP;
      cumulativeDepreciation += yearTotal;

      yearlyDepreciation.push({
        year,
        personalProperty: yearPP,
        siteImprovements: yearSI,
        realProperty: yearRP,
        total: yearTotal,
        cumulative: cumulativeDepreciation
      });
    }

    // Calculate 5-year totals
    const fiveYearTotal = yearlyDepreciation.slice(0, 5).reduce((sum, year) => sum + year.total, 0);

    return {
      currentYear: {
        personalProperty: year1PP,
        siteImprovements: year1SI,
        realProperty: year1RP,
        total: year1PP + year1SI + year1RP
      },
      yearlyDepreciation,
      fiveYearTotal
    };
  };

  // Calculate all scenarios
  const estimatedDepreciation = calculateScenarioDepreciation(estimatedAmounts);
  const optimisticDepreciation = calculateScenarioDepreciation(optimisticAmounts);
  const noStudyDepreciation = calculateScenarioDepreciation(null, true);

  // Calculate tax savings
  const taxRate = federal_tax_rate / 100;
  
  const calculateTaxSavings = (depreciation) => ({
    currentYear: depreciation.currentYear.total * taxRate,
    fiveYear: depreciation.fiveYearTotal * taxRate
  });

  const estimatedSavings = calculateTaxSavings(estimatedDepreciation);
  const optimisticSavings = calculateTaxSavings(optimisticDepreciation);
  const noStudySavings = calculateTaxSavings(noStudyDepreciation);

  return {
    buildingBasis,
    landValue,
    allocations: {
      estimated: {
        percentages: estimatedAllocation,
        amounts: estimatedAmounts
      },
      optimistic: {
        percentages: optimisticAllocation,
        amounts: optimisticAmounts
      }
    },
    depreciation: {
      estimated: estimatedDepreciation,
      optimistic: optimisticDepreciation,
      noStudy: noStudyDepreciation
    },
    taxSavings: {
      estimated: estimatedSavings,
      optimistic: optimisticSavings,
      noStudy: noStudySavings
    },
    fiveYearComparison: {
      withStudy: {
        estimated: estimatedDepreciation.fiveYearTotal,
        optimistic: optimisticDepreciation.fiveYearTotal
      },
      noStudy: noStudyDepreciation.fiveYearTotal,
      savings: {
        estimated: estimatedDepreciation.fiveYearTotal - noStudyDepreciation.fiveYearTotal,
        optimistic: optimisticDepreciation.fiveYearTotal - noStudyDepreciation.fiveYearTotal
      }
    }
  };
}