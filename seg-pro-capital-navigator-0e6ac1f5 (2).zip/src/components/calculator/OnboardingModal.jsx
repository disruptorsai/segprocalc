import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Play, ArrowRight, TrendingUp, DollarSign } from "lucide-react";

export default function OnboardingModal({ isOpen, onClose, onStart }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const steps = [
    {
      title: "Cost Segregation: Cash-Flow Impact",
      subtitle: "Conceptual illustration; not tax advice",
      duration: 1200
    },
    {
      title: "BEFORE Cost Segregation Study",
      content: "before",
      duration: 2800
    },
    {
      title: "",
      content: "arrow",
      duration: 1200
    },
    {
      title: "AFTER Cost Segregation Study", 
      content: "after",
      duration: 5300
    },
    {
      title: "Get your estimate in minutes",
      content: "cta",
      duration: 1500
    }
  ];

  useEffect(() => {
    if (!isOpen || !isAnimating) return;

    const timer = setTimeout(() => {
      if (currentStep < steps.length - 1) {
        setCurrentStep(prev => prev + 1);
      } else {
        setIsAnimating(false);
      }
    }, steps[currentStep].duration);

    return () => clearTimeout(timer);
  }, [currentStep, isOpen, isAnimating]);

  const startAnimation = () => {
    setCurrentStep(0);
    setIsAnimating(true);
  };

  const handleStart = () => {
    onStart();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white">
        <CardContent className="p-0 relative">
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>

          {/* Animation Container */}
          <div className="aspect-video bg-gradient-to-br from-slate-50 to-blue-50 relative overflow-hidden">
            
            {/* Title Screen */}
            {currentStep === 0 && (
              <div className="absolute inset-0 flex items-center justify-center text-center animate-in fade-in duration-500">
                <div>
                  <h1 className="text-4xl font-bold text-slate-900 mb-2">
                    Cost Segregation
                  </h1>
                  <h2 className="text-2xl font-semibold text-[#0A4EAF] mb-4">
                    Cash-Flow Impact
                  </h2>
                  <p className="text-sm text-slate-500">
                    Conceptual illustration; not tax advice
                  </p>
                </div>
              </div>
            )}

            {/* Before Section */}
            {currentStep === 1 && (
              <div className="absolute inset-0 grid grid-cols-1 p-8">
                <div className="animate-in slide-in-from-left duration-700">
                  <div className="bg-red-50 border border-red-200 rounded-xl p-6 h-full">
                    <h3 className="text-xl font-bold text-red-700 mb-6">
                      BEFORE Cost Segregation Study
                    </h3>
                    
                    <div className="flex flex-col items-center justify-center h-48 mb-6">
                      <div className="w-32 h-32 bg-slate-700 rounded-full flex items-center justify-center animate-in zoom-in duration-500 delay-300">
                        <div className="text-white text-center">
                          <div className="text-lg font-bold">100% 39-Year</div>
                          <div className="text-sm">Real Property</div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 animate-in fade-in duration-500 delay-700">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm text-slate-700">Straight-line over 39 years</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm text-slate-700">Minimal early-year deductions</span>
                      </div>
                    </div>

                    <div className="mt-4 animate-in zoom-in duration-300 delay-1000">
                      <span className="inline-block bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
                        +$0 cash impact
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Arrow Transition */}
            {currentStep === 2 && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="animate-in zoom-in duration-700">
                  <ArrowRight className="w-16 h-16 text-[#0A4EAF] animate-pulse" />
                </div>
              </div>
            )}

            {/* After Section */}
            {currentStep === 3 && (
              <div className="absolute inset-0 grid grid-cols-1 p-8">
                <div className="animate-in slide-in-from-right duration-700">
                  <div className="bg-green-50 border border-green-200 rounded-xl p-6 h-full">
                    <h3 className="text-xl font-bold text-green-700 mb-6">
                      AFTER Cost Segregation Study
                    </h3>
                    
                    {/* Pie Chart Representation */}
                    <div className="flex flex-col items-center justify-center h-48 mb-6">
                      <div className="relative w-32 h-32 animate-in spin-in duration-1000 delay-300">
                        {/* Simplified pie chart using CSS */}
                        <div className="w-full h-full rounded-full border-8 border-slate-700 relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-[#F47C00] via-[#0A4EAF] to-slate-700 rounded-full"></div>
                        </div>
                      </div>
                      
                      <div className="mt-4 space-y-1 text-center animate-in fade-in duration-500 delay-800">
                        <div className="flex items-center gap-2 justify-center text-sm">
                          <div className="w-3 h-3 bg-slate-700 rounded-full"></div>
                          <span>39-Year Real Property (65%)</span>
                        </div>
                        <div className="flex items-center gap-2 justify-center text-sm">
                          <div className="w-3 h-3 bg-[#F47C00] rounded-full"></div>
                          <span>15-Year Personal Property (20%)</span>
                        </div>
                        <div className="flex items-center gap-2 justify-center text-sm">
                          <div className="w-3 h-3 bg-[#0A4EAF] rounded-full"></div>
                          <span>5-Year Personal Property (15%)</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 animate-in fade-in duration-500 delay-1200">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-slate-700">Accelerated depreciation on 5- & 15-year classes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-slate-700">Larger deductions in early years</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-slate-700">Increased cash flow from tax savings</span>
                      </div>
                    </div>

                    {/* Cash Bar Animation */}
                    <div className="mt-4 animate-in slide-in-from-bottom duration-700 delay-1500">
                      <div className="bg-green-100 rounded-full h-6 overflow-hidden">
                        <div className="bg-green-500 h-full animate-in slide-in-from-left duration-1000 delay-1800" style={{width: '85%'}}></div>
                      </div>
                      <p className="text-sm text-green-700 mt-2 font-medium">
                        Projected tax savings: $________
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* CTA End Card */}
            {currentStep === 4 && (
              <div className="absolute inset-0 flex items-center justify-center text-center animate-in fade-in duration-500">
                <div>
                  <div className="flex items-center justify-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-[#0A4EAF] rounded-xl flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-2xl font-bold text-slate-900">SegPro</span>
                  </div>
                  
                  <h1 className="text-3xl font-bold text-slate-900 mb-2">
                    Get your estimate in minutes
                  </h1>
                  <p className="text-lg text-slate-600 mb-6">
                    Upload basic property details to see potential savings
                  </p>
                  
                  <Button 
                    onClick={handleStart}
                    className="bg-[#0A4EAF] hover:bg-[#0A4EAF]/90 text-white px-8 py-3 text-lg animate-pulse"
                  >
                    Start My Estimate
                  </Button>
                  
                  <p className="text-xs text-slate-500 mt-4">
                    Conceptual illustration; not tax advice
                  </p>
                </div>
              </div>
            )}

            {/* Play Button Overlay (when not animating) */}
            {!isAnimating && currentStep === 0 && (
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={startAnimation}
                  className="w-20 h-20 bg-[#0A4EAF] rounded-full flex items-center justify-center hover:bg-[#0A4EAF]/90 transition-colors shadow-lg"
                >
                  <Play className="w-8 h-8 text-white ml-1" />
                </button>
              </div>
            )}
          </div>

          {/* Bottom Controls */}
          <div className="p-6 bg-white border-t">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {steps.map((_, index) => (
                  <div 
                    key={index}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index <= currentStep ? 'bg-[#0A4EAF]' : 'bg-slate-300'
                    }`}
                  />
                ))}
              </div>
              
              <div className="flex gap-3">
                {!isAnimating ? (
                  <>
                    <Button variant="outline" onClick={onClose}>
                      Skip Intro
                    </Button>
                    <Button onClick={startAnimation} className="bg-[#0A4EAF] hover:bg-[#0A4EAF]/90">
                      <Play className="w-4 h-4 mr-2" />
                      Watch Animation
                    </Button>
                  </>
                ) : (
                  <Button variant="outline" onClick={() => setIsAnimating(false)}>
                    Skip Animation
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}